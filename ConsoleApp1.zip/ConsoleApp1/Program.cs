﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace SecuritySystem
{
    class Program
    {
        static string usersFile = "nameuser.txt";
        static string logFile = "us_book.txt";
        static int maxUsers = 12;

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Welcome to the Security System");
                Console.Write("1. Login\n2. Register\nChoose an option: ");
                string choice = Console.ReadLine();

                if (choice == "1")
                {
                    Console.Write("Enter Username: ");
                    string username = Console.ReadLine();
                    Console.Write("Enter Password: ");
                    string password = Console.ReadLine();

                    if (AuthenticateUser(username, password, out string permissions))
                    {
                        Console.WriteLine("Authentication successful.");
                        if (PeriodicAuthentication(username))
                        {
                            UserMenu(username, permissions);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Authentication failed. Access denied.");
                    }
                }
                else if (choice == "2")
                {
                    RegisterUserInteractive();
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                }
            }
        }

        // Меню для користувача після успішної автентифікації
        static void UserMenu(string username, string permissions)
        {
            while (true)
            {
                Console.WriteLine("\nUser Options:");
                Console.WriteLine("1. Encrypt File");
                Console.WriteLine("2. Decrypt File");
                Console.WriteLine("3. View Access Level");
                Console.WriteLine("4. Logout");
                Console.Write("Choose an option: ");
                string choice = Console.ReadLine();

                if (choice == "1")
                {
                    if (permissions.Contains("W"))
                        EncryptFile("input.txt", "close.txt");
                    else
                        Console.WriteLine("Permission denied: You do not have 'W' (Write) access.");
                }
                else if (choice == "2")
                {
                    if (permissions.Contains("R"))
                        DecryptFile("close.txt", "out.txt");
                    else
                        Console.WriteLine("Permission denied: You do not have 'R' (Read) access.");
                }
                else if (choice == "3")
                {
                    Console.WriteLine($"Your access level: {permissions}");
                }
                else if (choice == "4")
                {
                    Console.WriteLine("Logging out and returning to main menu.");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid option. Please try again.");
                }
            }
        }

        // Періодична перевірка автентичності
        static bool PeriodicAuthentication(string username)
        {
            Console.WriteLine("\nPeriodic Authentication Check:");
            Console.Write("What is 5 + 3? "); // Приклад питання
            string answer = Console.ReadLine();

            if (answer == "8")
            {
                Console.WriteLine("Authentication check passed.");
                return true;
            }
            else
            {
                Console.WriteLine("Authentication check failed. Returning to main menu.");
                return false;
            }
        }

        // Реєстрація нового користувача
        static void RegisterUserInteractive()
        {
            var users = File.Exists(usersFile) ? File.ReadAllLines(usersFile).ToList() : new List<string>();

            if (users.Count >= maxUsers)
            {
                Console.WriteLine("Maximum number of users reached.");
                return;
            }

            Console.Write("Enter Username for new user: ");
            string username = Console.ReadLine();

            Console.Write("Enter Password for new user: ");
            string password = Console.ReadLine();

            Console.Write("Enter Access Level (E - Execute, R - Read, W - Write, A - Append; e.g., 'RW'): ");
            string accessLevel;
            while (true)
            {
                accessLevel = Console.ReadLine().ToUpper();
                if (IsValidAccessLevel(accessLevel))
                    break;
                Console.Write("Invalid access level. Please enter a combination of E, R, W, A (e.g., 'RW'): ");
            }

            RegisterUser(username, password, accessLevel);
            Console.WriteLine("User registered successfully. Returning to main menu...");
        }

        static bool IsValidAccessLevel(string accessLevel)
        {
            foreach (char c in accessLevel)
            {
                if (!"ERWA".Contains(c))
                    return false;
            }
            return true;
        }

        // Реєстрація користувача
        static void RegisterUser(string username, string password, string accessLevel)
        {
            var users = File.Exists(usersFile) ? File.ReadAllLines(usersFile).ToList() : new List<string>();

            string userEntry = $"{username},{password},{accessLevel}";
            users.Add(userEntry);
            File.WriteAllLines(usersFile, users);

            Console.WriteLine($"User {username} registered successfully with access level {accessLevel}.");
        }

        // Ідентифікація користувача
        static bool AuthenticateUser(string username, string password, out string permissions)
        {
            permissions = string.Empty;
            var users = File.Exists(usersFile) ? File.ReadAllLines(usersFile) : Array.Empty<string>();

            foreach (var user in users)
            {
                var userInfo = user.Split(',');
                if (userInfo[0] == username && userInfo[1] == password)
                {
                    permissions = userInfo[2];
                    LogAction(username, "Authenticated successfully.");
                    return true;
                }
            }

            LogAction(username, "Authentication failed.");
            return false;
        }

        // Шифрування файлу
        static void EncryptFile(string inputFile, string outputFile)
        {
            string key = "0123456789ABCDEF"; // Приклад ключа
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);

            using (Aes aes = Aes.Create())
            {
                aes.Key = keyBytes;
                aes.IV = keyBytes.Take(16).ToArray();
                aes.Padding = PaddingMode.PKCS7;

                using (FileStream fsEncrypt = new FileStream(outputFile, FileMode.Create))
                using (CryptoStream csEncrypt = new CryptoStream(fsEncrypt, aes.CreateEncryptor(), CryptoStreamMode.Write))
                using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                {
                    swEncrypt.Write(File.ReadAllText(inputFile));
                }
            }
            Console.WriteLine("File encrypted successfully.");
        }

        // Дешифрування файлу
        static void DecryptFile(string inputFile, string outputFile)
        {
            string key = "0123456789ABCDEF"; // Приклад ключа
            byte[] keyBytes = Encoding.UTF8.GetBytes(key);

            using (Aes aes = Aes.Create())
            {
                aes.Key = keyBytes;
                aes.IV = keyBytes.Take(16).ToArray();
                aes.Padding = PaddingMode.PKCS7;

                using (FileStream fsDecrypt = new FileStream(inputFile, FileMode.Open))
                using (CryptoStream csDecrypt = new CryptoStream(fsDecrypt, aes.CreateDecryptor(), CryptoStreamMode.Read))
                using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                {
                    File.WriteAllText(outputFile, srDecrypt.ReadToEnd());
                }
            }
            Console.WriteLine("File decrypted successfully.");
        }

        // Логування дій
        static void LogAction(string username, string action)
        {
            string logEntry = $"{DateTime.Now}: {username} - {action}";
            File.AppendAllText(logFile, logEntry + Environment.NewLine);
        }
    }
}